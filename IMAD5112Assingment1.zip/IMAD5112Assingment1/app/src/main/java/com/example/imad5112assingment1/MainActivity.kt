package com.example.imad5112assingment1

import android.os.Bundle
import android.text.TextUtils
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Reference: https://developer.android.com/develop/ui/views/components/button#:~:text=To%20customize%20individual%20buttons%20with,background%2C%20font%2C%20and%20size.
        val edtTimeInput: EditText = findViewById(R.id.edtTimeInput)
        val btnSubmit: Button = findViewById(R.id.btnSubmit)
        val txtMealSuggestion: TextView = findViewById(R.id.txtMealSuggestion)
        val txtFeedback: TextView = findViewById(R.id.txtFeedback)
        val btnClear: Button = findViewById(R.id.btnClear)
        val btnExit: Button = findViewById(R.id.btnExit)

        // Reference: https://kotlinlang.org/api/core/kotlin-stdlib/kotlin.collections/list-of.html
        val breakfastTimes = listOf("6am", "7am", "8am", "9am", "10am", "11am", "morning")
        val midMorningSnackTimes = listOf("10am", "11am", "mid-morning")
        val lunchTimes = listOf("12pm", "1pm", "2pm", "midday", "noon")
        val afternoonSnackTimes = listOf("3pm", "4pm", "afternoon")
        val dinnerTimes = listOf("5pm", "6pm", "7pm", "8pm", "9pm", "evening")
        val afterDinnerSnackTimes = listOf("8pm", "9pm", "10pm", "after dinner", "night")

        btnSubmit.setOnClickListener {
            val timeOfDay = edtTimeInput.text.toString().replace(" ", "").lowercase()

            // Reference: https://kotlinlang.org/api/core/kotlin-stdlib/kotlin.collections/list-of.html
            val breakfastSuggestions = listOf("pancakes", "omelette", "cereal")
            val midMorningSnackSuggestions = listOf("fruit", "yogurt", "smoothie")
            val lunchSuggestions = listOf("sandwich", "salad", "sushi")
            val afternoonSnackSuggestions = listOf("nuts", "granola bar", "veggies with hummus")
            val dinnerSuggestions = listOf("pasta", "steak", "stir-fry")
            val afterDinnerSnackSuggestions = listOf("dark chocolate", "ice cream", "cheese and crackers")

            // Reference: https://stackoverflow.com/questions/59321405/kotlin-isnullorempty-vs-textutils-isempty
            if (TextUtils.isEmpty(timeOfDay)) {
                txtFeedback.text = "Please enter a time."
            } else {
                txtFeedback.text = ""
                // https://developermemos.com/posts/random-list-item-kotlin
                txtMealSuggestion.text = when {
                    timeOfDay in breakfastTimes -> "How about some ${breakfastSuggestions.random()} for breakfast?"
                    timeOfDay in midMorningSnackTimes -> "A mid-morning snack like ${midMorningSnackSuggestions.random()} would be great."
                    timeOfDay in lunchTimes -> "Maybe ${lunchSuggestions.random()} for lunch?"
                    timeOfDay in afternoonSnackTimes -> "How about some ${afternoonSnackSuggestions.random()} for an afternoon snack?"
                    timeOfDay in dinnerTimes -> "How about ${dinnerSuggestions.random()} for dinner?"
                    timeOfDay in afterDinnerSnackTimes -> "An after-dinner snack like ${afterDinnerSnackSuggestions.random()} sounds nice."
                    else -> "Please enter a valid time (e.g., 8am, 1pm, Morning, Midday, Night)."
                }
            }
        }

        btnClear.setOnClickListener {
            edtTimeInput.text.clear()
            txtMealSuggestion.text = "Your meal suggestion will appear here"
            txtFeedback.text = ""
        }

        btnExit.setOnClickListener {
            finish()
        }
    }
}

// Reference: https://developer.android.com/develop/ui/views/graphics/drawables#:~:text=Vector%20drawables%20overview.-,Create%20drawables%20from%20resource%20images,well%20suited%20for%20this%20technique.
// Reference: https://dev.to/tahirdotdev/linking-git-with-github-and-android-studio-a-step-by-step-guide-1pd0